## NEXT

* Added unit tests.

## 2.0.2

* Replaced reference to `shared_preferences` plugin with the `url_launcher` in the README.

## 2.0.1

* Updated installation instructions in README.

## 2.0.0

* Migrate to null-safety.
* Update the example app: remove the deprecated `RaisedButton` and `FlatButton` widgets.
* Set `implementation` in pubspec.yaml

## 0.0.2+1

* Update Flutter SDK constraint.

## 0.0.2

* Update integration test examples to use `testWidgets` instead of `test`.

## 0.0.1+3

* Update Dart SDK constraint in example.

## 0.0.1+2

* Check in windows/ directory for example/

## 0.0.1+1

* Update README to reflect endorsement.

## 0.0.1

* Initial Windows implementation of `url_launcher`.
