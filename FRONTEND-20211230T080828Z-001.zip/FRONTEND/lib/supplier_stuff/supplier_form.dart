import 'dart:html';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:inventory_management/apis/product_api.dart';
import 'package:inventory_management/apis/supplier_api.dart';
import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/supplier.dart';
import 'package:inventory_management/classes/supplies.dart';
import 'package:inventory_management/widgets/custom_text_field.dart';
import 'package:inventory_management/widgets/location_search_text_field.dart';
import 'package:simple_rich_text/simple_rich_text.dart';

class SupplierForm extends StatefulWidget {
  Supplier? supplier;
  late Function() done;
  SupplierForm(this.done, {this.supplier});

  @override
  _SupplierFormState createState() => _SupplierFormState();
}

class _SupplierFormState extends State<SupplierForm> {
  double height = 0, width = 0, screenHeight = 780, screenWidth = 360;
  //
  TextEditingController companyName = TextEditingController();
  TextEditingController phoneNumber = TextEditingController();
  //
  List<TextEditingController> products = [];
  List<TextEditingController> deliverTime = [];
  List<TextEditingController> price = [];
  //
  List<Supplies> supplies = [];
  //
  int productsLength = 1;

  Supplier? supplier;

  Color green = const Color.fromRGBO(0, 115, 86, 1),
      back = const Color.fromRGBO(242, 242, 252, 1);

  @override
  void initState() {
    supplier = widget.supplier;
    if (supplier != null) {
      companyName.text = supplier!.companyName;
      phoneNumber.text = supplier!.phoneNumber;
      supplies = supplier!.supplies!;
      productsLength = supplier!.supplies!.length;
      for (int i = 0; i < supplier!.supplies!.length; i++) {
        products.add(
            TextEditingController(text: supplier!.supplies![i].product.name));
        deliverTime.add(TextEditingController(
            text: supplier!.supplies![i].days.toString()));
        price.add(TextEditingController(
          text: supplier!.supplies![i].cost.toStringAsFixed(3),
        ));
      }
    } else {
      products = [TextEditingController()];
      deliverTime = [TextEditingController(text: '1')];
      price = [TextEditingController(text: '0')];
    } // TODO: implement initState
    super.initState();
  }

  @override
  void didChangeDependencies() {
    if (height == 0) {
      height = MediaQuery.of(context).size.height;
      width = MediaQuery.of(context).size.width;
    }
    super.didChangeDependencies();
  }

  h(double x) => height * (x / screenHeight);
  w(double x) => width * (x / screenWidth);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: w(screenWidth * 0.65),
      height: h(screenHeight * 0.75),
      child: Stack(
        children: [
          SizedBox(
            width: w(screenWidth * 0.65),
            height: h(screenHeight * 0.7),
            child: Form(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        top: h(10),
                        left: w(0),
                      ),
                      child: SimpleRichText(
                        'Add New Supplier',
                        style: GoogleFonts.poppins(
                            fontWeight: FontWeight.w600,
                            fontSize: h(19),
                            color: Colors.black87.withOpacity(0.6),
                            decoration: TextDecoration.underline),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: h(20), left: w(0)),
                      child: null,
                    ),
                    SizedBox(
                      width: w(screenWidth * 0.25),
                      height: h(screenHeight * 0.1),
                      child: Center(
                        child: CustomTextField(
                          width: w(screenWidth * 0.25),
                          height: h(screenHeight * 0.06),
                          labelSize: h(10),
                          controller: companyName,
                          padding: EdgeInsets.only(top: h(5)),
                          fontSize: h(16),
                          textColor: Colors.black.withOpacity(0.5),
                          fillColor: Colors.grey.shade300.withOpacity(0.3),
                          label: 'Company Name',
                          hintText: 'Company Name',
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: h(15), left: w(0)),
                      child: null,
                    ),
                    SizedBox(
                      width: w(screenWidth * 0.25),
                      height: h(screenHeight * 0.1),
                      child: Center(
                        child: CustomTextField(
                          width: w(screenWidth * 0.25),
                          height: h(screenHeight * 0.06),
                          labelSize: h(10),
                          controller: phoneNumber,
                          padding: EdgeInsets.only(top: h(5)),
                          fontSize: h(16),
                          textColor: Colors.black.withOpacity(0.5),
                          fillColor: Colors.grey.shade300.withOpacity(0.3),
                          label: 'Phone Number',
                          hintText: 'Phone Number',
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: h(15), left: w(0)),
                      child: null,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (int i = 0; i < productsLength; i++)
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Center(
                                child: LocationSearchTextField(
                                  '',
                                  h(screenHeight),
                                  w(screenWidth * 0.15),
                                  screenHeight,
                                  screenWidth,
                                  products[i],
                                  'Product',
                                  fontSize: h(16),
                                  textColor: Colors.black.withOpacity(0.5),
                                  fillColor:
                                      Colors.grey.shade300.withOpacity(0.3),
                                  api: ProductApi.getProductsSearch,
                                  bypass: true,
                                  dropDownButton: true,
                                  showAll: true,
                                  callBack: (val) {
                                    if (val == null) return;
                                    if (supplies.length < productsLength) {
                                      supplies.add(Supplies(
                                        val,
                                        double.parse(price[i].text.toString()),
                                        int.parse(
                                            deliverTime[i].text.toString()),
                                      ));
                                    } else {
                                      supplies[i].product = val;
                                    }
                                  },
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsets.only(top: h(0), left: w(10)),
                                child: null,
                              ),
                              SizedBox(
                                width: w(screenWidth * 0.1),
                                height: h(screenHeight * 0.1),
                                child: Center(
                                  child: CustomTextField(
                                    width: w(screenWidth * 0.09),
                                    height: h(screenHeight * 0.06),
                                    labelSize: h(10),
                                    controller: price[i],
                                    padding: EdgeInsets.only(top: h(5)),
                                    fontSize: h(16),
                                    textColor: Colors.black.withOpacity(0.5),
                                    fillColor:
                                        Colors.grey.shade300.withOpacity(0.3),
                                    label: 'Price',
                                    hintText: 'Price',
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsets.only(top: h(0), left: w(10)),
                                child: null,
                              ),
                              SizedBox(
                                width: w(screenWidth * 0.1),
                                height: h(screenHeight * 0.1),
                                child: Center(
                                  child: CustomTextField(
                                    width: w(screenWidth * 0.09),
                                    height: h(screenHeight * 0.06),
                                    labelSize: h(10),
                                    controller: deliverTime[i],
                                    padding: EdgeInsets.only(top: h(5)),
                                    fontSize: h(16),
                                    textColor: Colors.black.withOpacity(0.5),
                                    fillColor:
                                        Colors.grey.shade300.withOpacity(0.3),
                                    label: 'Delivery Time',
                                    hintText: 'Delivery Time',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        Padding(
                          padding: EdgeInsets.only(top: h(20), left: w(0)),
                          child: null,
                        ),
                        Row(
                          children: [
                            InkWell(
                              onTap: () {
                                productsLength++;
                                products.add(TextEditingController());
                                price.add(TextEditingController(text: '0'));
                                deliverTime
                                    .add(TextEditingController(text: '1'));
                                setState(() {});
                              },
                              child: SimpleRichText(
                                'Add another row',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w500,
                                  fontSize: h(15),
                                  color: Colors.grey,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: h(0), left: w(10)),
                              child: null,
                            ),
                            InkWell(
                              onTap: () {
                                productsLength--;
                                products.removeLast();
                                price.removeLast();
                                deliverTime.removeLast();
                                if (supplies.length > productsLength)
                                  supplies.removeLast();
                                setState(() {});
                              },
                              child: SimpleRichText(
                                'Delete last row',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w500,
                                  fontSize: h(15),
                                  color: Colors.grey,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: h(10),
            child: Padding(
              padding: EdgeInsets.only(left: w(70)),
              child: Material(
                child: InkWell(
                  splashColor: Colors.white,
                  onTap: () {
                    for (int i = 0; i < productsLength; i++) {
                      supplies[i].days =
                          int.parse(deliverTime[i].text.toString());
                      supplies[i].cost = double.parse(price[i].text.toString());
                    }
                    if (supplier != null) {
                      supplier = Supplier(supplier!.supplierId,
                          companyName.text, phoneNumber.text,
                          supplies: supplies);
                    } else {
                      supplier = Supplier(
                          -1, companyName.text, phoneNumber.text,
                          supplies: supplies);
                    }

                    SupplierApi.addOrUpdateSupplier(supplier!)
                        .then((value) => widget.done());
                  },
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    width: w(60),
                    height: h(50),
                    decoration: BoxDecoration(
                      color: green.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.check_circle_outline,
                            color: Colors.white,
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                              top: h(0),
                              left: w(3),
                            ),
                            child: SimpleRichText(
                              'Submit',
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w500,
                                fontSize: w(4),
                                color: Colors.white,
                              ),
                              textAlign: TextAlign.left,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
