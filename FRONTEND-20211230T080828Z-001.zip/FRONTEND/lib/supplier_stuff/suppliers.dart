import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:inventory_management/apis/supplier_api.dart';
import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/supplier.dart';
import 'package:inventory_management/supplier_stuff/supplier_form.dart';
import 'package:simple_rich_text/simple_rich_text.dart';

import 'package:inventory_management/classes/supplies.dart';

class Suppliers extends StatefulWidget {
  @override
  State<Suppliers> createState() => _SuppliersState();
}

class _SuppliersState extends State<Suppliers> {
  List<Supplier>? suppliers;
  List<Widget>? suppliersGrid;
  bool addForm = false, edit = false;
  int editIndex = -1;
  Color green = const Color.fromRGBO(0, 115, 86, 1),
      back = const Color.fromRGBO(242, 242, 252, 1);
  double height = 0, width = 0, screenHeight = 780, screenWidth = 360;
  @override
  void didChangeDependencies() {
    if (height == 0) {
      height = MediaQuery.of(context).size.height;
      width = MediaQuery.of(context).size.width;
    }
    super.didChangeDependencies();
  }

  @override
  void initState() {
    SupplierApi.getSuppliers().then((value) {
      suppliers = value;
      setState(() {});
    });
    super.initState();
  }

  void done() {
    addForm = false;
    edit = false;
    setState(() {});
    SupplierApi.getSuppliers().then((value) {
      suppliers = value;
      setState(() {});
    });
  }

  h(double x) => height * (x / screenHeight);
  w(double x) => width * (x / screenWidth);
  @override
  Widget build(BuildContext context) {
    return Container(
      width: w(screenWidth * 0.7),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(
                  top: h(5),
                  left: w(10),
                ),
                child: SimpleRichText(
                  'Suppliers',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w600,
                    fontSize: 35,
                    color: Colors.black.withOpacity(0.8),
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  top: h(20),
                  left: w(130),
                  right: w(10),
                ),
                child: Material(
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      setState(() {
                        addForm = !addForm;
                      });
                    },
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      width: w(60),
                      height: h(50),
                      decoration: BoxDecoration(
                        color: green.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            addForm
                                ? Container()
                                : const Icon(
                                    Icons.add,
                                    color: Colors.white,
                                  ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: h(0),
                                left: w(3),
                              ),
                              child: SimpleRichText(
                                addForm ? 'Back to Suppliers' : 'Add Supplier',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w500,
                                  fontSize: w(4),
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.only(top: h(10), left: w(0), bottom: h(10)),
            child: null,
          ),
          Divider(),
          suppliers == null
              ? const CircularProgressIndicator()
              : edit
                  ? SupplierForm(
                      done,
                      supplier: suppliers![editIndex],
                    )
                  : addForm
                      ? SupplierForm(done)
                      : Container(
                          height: h(screenHeight * 0.7),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(
                                    top: h(20),
                                    left: w(0),
                                    bottom: h(20),
                                  ),
                                  child: Row(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h(0),
                                          left: w(10),
                                        ),
                                        child: SimpleRichText(
                                          'Supplier Id',
                                          style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.w600,
                                            fontSize: w(4),
                                            color:
                                                Colors.black.withOpacity(0.7),
                                          ),
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h(0),
                                          left: w(20),
                                        ),
                                        child: SimpleRichText(
                                          'Company Name',
                                          style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.w600,
                                            fontSize: w(4),
                                            color:
                                                Colors.black.withOpacity(0.7),
                                          ),
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h(0),
                                          left: w(25),
                                        ),
                                        child: SimpleRichText(
                                          'Phone Number',
                                          style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.w600,
                                            fontSize: w(4),
                                            color:
                                                Colors.black.withOpacity(0.7),
                                          ),
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h(0),
                                          left: w(20),
                                        ),
                                        child: SimpleRichText(
                                          'Products',
                                          style: GoogleFonts.poppins(
                                            fontWeight: FontWeight.w600,
                                            fontSize: w(4),
                                            color:
                                                Colors.black.withOpacity(0.7),
                                          ),
                                          textAlign: TextAlign.left,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Divider(),
                                Padding(
                                  padding:
                                      EdgeInsets.only(top: h(0), left: w(0)),
                                  child: null,
                                ),
                                for (int i = 0; i < suppliers!.length; i++)
                                  Column(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h(5),
                                          left: w(10),
                                        ),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              width: w(screenWidth * 0.12),
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(10),
                                              ),
                                              child: SimpleRichText(
                                                suppliers![i]
                                                    .supplierId
                                                    .toString(),
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w(3.5),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Container(
                                              width: w(screenWidth * 0.18),
                                              child: SimpleRichText(
                                                suppliers![i]
                                                    .companyName
                                                    .toString(),
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w(3.5),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Container(
                                              width: w(screenWidth * 0.1),
                                              child: SimpleRichText(
                                                suppliers![i]
                                                    .phoneNumber
                                                    .toString(),
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: w(3.5),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(5),
                                              ),
                                              child: Container(
                                                padding: EdgeInsets.all(
                                                  h(15),
                                                ),
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  color: Colors.grey
                                                      .withOpacity(0.2),
                                                ),
                                                child: SingleChildScrollView(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      for (Supplies product
                                                          in suppliers![i]
                                                              .supplies!)
                                                        SimpleRichText(
                                                          '${product.product.name.toString()} - \$${product.cost.toStringAsFixed(2)} - ${product.days} days',
                                                          style: GoogleFonts
                                                              .poppins(
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontSize: w(3.5),
                                                            color: Colors.black
                                                                .withOpacity(
                                                                    0.7),
                                                          ),
                                                          textAlign:
                                                              TextAlign.left,
                                                        ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  top: h(0), left: w(10)),
                                              child: null,
                                            ),
                                            InkWell(
                                              onTap: () {
                                                setState(() {
                                                  edit = true;
                                                  editIndex = i;
                                                });
                                              },
                                              child: Container(
                                                child: const Center(
                                                  child: Icon(Icons.edit,
                                                      color: Colors.white),
                                                ),
                                                padding: EdgeInsets.all(h(4)),
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: green.withOpacity(0.5),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  top: h(0), left: w(5)),
                                              child: null,
                                            ),
                                            InkWell(
                                              onTap: () {
                                                SupplierApi.deleteSupplier(
                                                        suppliers![i])
                                                    .then((value) {
                                                  suppliers!.removeAt(i);
                                                  setState(() {});
                                                });
                                              },
                                              child: Container(
                                                child: const Center(
                                                  child: Icon(Icons.delete,
                                                      color: Colors.white),
                                                ),
                                                padding: EdgeInsets.all(h(4)),
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: green.withOpacity(0.5),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Divider(),
                                    ],
                                  ),
                              ],
                            ),
                          ),
                        ),
        ],
      ),
    );
  }
}
