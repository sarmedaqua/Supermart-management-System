import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:inventory_management/items_stuff/products.dart';
import 'package:inventory_management/purchase_order_stuff/purchase_orders.dart';
import 'package:inventory_management/supplier_stuff/suppliers.dart';
import 'package:simple_rich_text/simple_rich_text.dart';

class CenteralPage extends StatefulWidget {
  @override
  State<CenteralPage> createState() => _CenterState();
}

class _CenterState extends State<CenteralPage> {
  int navRailInd = 1;
  double height = 0, width = 0, screenHeight = 780, screenWidth = 360;
  @override
  void didChangeDependencies() {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    super.didChangeDependencies();
  }

  h(double x) => height * (x / screenHeight);
  w(double x) => width * (x / screenWidth);
  Color green = const Color.fromRGBO(0, 115, 86, 1),
      back = const Color.fromRGBO(242, 242, 252, 1);
  List<Widget> options = [], screens = [];

  @override
  Widget build(BuildContext context) {
    options = [
      Container(
        width: w(screenWidth * 0.12),
        decoration: navRailInd != 1
            ? null
            : BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(2, 4),
                      blurRadius: 1,
                      spreadRadius: 1,
                    )
                  ]),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(5)),
                  child: Icon(Icons.assignment_ind,
                      color: navRailInd != 1 ? Colors.white : Colors.black),
                ),
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(3)),
                  child: Text(
                    'Suppliers',
                    style: GoogleFonts.poppins(
                        color: navRailInd != 1 ? Colors.white : Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      Container(
        width: w(screenWidth * 0.12),
        decoration: navRailInd != 2
            ? null
            : BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(2, 4),
                      blurRadius: 1,
                      spreadRadius: 1,
                    )
                  ]),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(5)),
                  child: Icon(Icons.list_alt,
                      color: navRailInd != 2 ? Colors.white : Colors.black),
                ),
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(3)),
                  child: Text(
                    'Items',
                    style: GoogleFonts.poppins(
                        color: navRailInd != 2 ? Colors.white : Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      Container(
        width: w(screenWidth * 0.14),
        decoration: navRailInd != 3
            ? null
            : BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(2, 4),
                      blurRadius: 1,
                      spreadRadius: 1,
                    )
                  ]),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(8)),
                  child: Icon(Icons.inventory,
                      color: navRailInd != 3 ? Colors.white : Colors.black),
                ),
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(3)),
                  child: Text(
                    'Purchase Orders',
                    style: GoogleFonts.poppins(
                        color: navRailInd != 3 ? Colors.white : Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      Container(
        width: w(screenWidth * 0.14),
        decoration: navRailInd != 5
            ? null
            : BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(2, 4),
                      blurRadius: 1,
                      spreadRadius: 1,
                    )
                  ]),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(8)),
                  child: Icon(Icons.settings,
                      color: navRailInd != 5 ? Colors.white : Colors.black),
                ),
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(3)),
                  child: Text(
                    'Settings',
                    style: GoogleFonts.poppins(
                        color: navRailInd != 5 ? Colors.white : Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      Container(
        width: w(screenWidth * 0.14),
        decoration: navRailInd != 6
            ? null
            : BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(2, 4),
                      blurRadius: 1,
                      spreadRadius: 1,
                    )
                  ]),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(8)),
                  child: Icon(Icons.logout,
                      color: navRailInd != 6 ? Colors.white : Colors.black),
                ),
                Padding(
                  padding: EdgeInsets.only(top: h(0), left: w(3)),
                  child: Text(
                    'Log Out',
                    style: GoogleFonts.poppins(
                        color: navRailInd != 6 ? Colors.white : Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ];
    screens = [
      Suppliers(),
      Products(),
      PurchaseOrders(),
    ];
    return Scaffold(
      backgroundColor: back,
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: w(5), top: h(15)),
            child: Container(
              decoration: BoxDecoration(
                  color: green,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(2, 4),
                      blurRadius: 1,
                      spreadRadius: 1,
                    )
                  ]),
              height: h(screenHeight * 0.8),
              width: w(screenWidth * 0.18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Padding(
                      padding: EdgeInsets.only(left: w(0), top: h(5)),
                      child: Text(
                        'Inventory.',
                        style: GoogleFonts.poppins(
                          color: Colors.white.withOpacity(0.9),
                          fontWeight: FontWeight.w500,
                          fontSize: h(24),
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                  ),
                  Divider(
                    color: Colors.white.withOpacity(0.6),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: h(0), left: w(0)),
                    child: Container(
                      height: h(screenHeight * 0.7),
                      child: Column(
                        children: [
                          for (int i = 0; i < options.length - 2; i++)
                            Padding(
                              padding: EdgeInsets.only(top: h(20), left: w(0)),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    navRailInd = i + 1;
                                  });
                                },
                                child: options[i],
                              ),
                            ),
                          Padding(
                            padding: EdgeInsets.only(top: h(20), left: w(0)),
                          ),
                          Divider(
                            color: Colors.white.withOpacity(0.6),
                          ),
                          for (int i = options.length - 2;
                              i < options.length;
                              i++)
                            Padding(
                              padding: EdgeInsets.only(top: h(15), left: w(0)),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    navRailInd = i;
                                  });
                                },
                                child: options[i],
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
              padding: EdgeInsets.only(
                top: h(10),
                left: w(10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: screens[navRailInd - 1],
              ))
        ],
      ),
    );
  }
}
