class ApiUrl {
  static String url = 'http://localhost:4000/';
}
