import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/supplier.dart';
import 'package:inventory_management/classes/supplies.dart';

class SupplierApi {
  static Future<List<Supplier>> getSuppliers() async {
    List<Supplier>? suppliers;
    List<Supplies>? supplies;
    supplies = [
      Supplies(Product('Product A', 'Shampoo', 20, 5.1), 4.0, 15),
      Supplies(Product('Product B', 'Chips', 17, 7.0), 3.0, 20),
      Supplies(Product('Product C', 'Drink', 25, 10.2), 7.0, 10),
      Supplies(Product('Product D', 'Soap', 50, 9.4), 5.0, 5),
      Supplies(Product('Product E', 'Detergent', 2, 15), 12, 30),
      Supplies(Product('Product F', 'Oil', 100, 2), 0.5, 2),
    ];
    suppliers = [
      Supplier(
        1,
        "Supplier A",
        "0321",
        supplies: supplies.sublist(1, 2),
      ),
      Supplier(
        2,
        "Supplier B",
        "0321",
        supplies: supplies.sublist(0, 4),
      ),
      Supplier(
        3,
        "Supplier C",
        "0321",
        supplies: supplies.sublist(2, 5),
      ),
      Supplier(
        4,
        "Supplier D",
        "0321",
        supplies: supplies,
      ),
      Supplier(
        5,
        "Supplier E",
        "0321",
        supplies: supplies.sublist(0, 1),
      ),
      Supplier(
        6,
        "Supplier F",
        "0321",
        supplies: supplies.sublist(3, 5),
      ),
      Supplier(
        7,
        "Supplier G",
        "0321",
        supplies: supplies.sublist(1, 4),
      ),
    ];
    return Future.value(suppliers);
  }

  static Future<List<dynamic>> getSuppliersSearch(String search) async {
    List<Supplier>? suppliers;
    List<Supplies>? supplies;
    supplies = [
      Supplies(Product('Product A', 'Shampoo', 20, 5.1), 4.0, 15),
      Supplies(Product('Product B', 'Chips', 17, 7.0), 3.0, 20),
      Supplies(Product('Product C', 'Drink', 25, 10.2), 7.0, 10),
      Supplies(Product('Product D', 'Soap', 50, 9.4), 5.0, 5),
      Supplies(Product('Product E', 'Detergent', 2, 15), 12, 30),
      Supplies(Product('Product F', 'Oil', 100, 2), 0.5, 2),
    ];
    suppliers = [
      Supplier(
        1,
        "Supplier A",
        "0321",
        supplies: supplies.sublist(1, 2),
      ),
      Supplier(
        2,
        "Supplier B",
        "0321",
        supplies: supplies.sublist(0, 4),
      ),
      Supplier(
        3,
        "Supplier C",
        "0321",
        supplies: supplies.sublist(2, 5),
      ),
      Supplier(
        4,
        "Supplier D",
        "0321",
        supplies: supplies,
      ),
      Supplier(
        5,
        "Supplier E",
        "0321",
        supplies: supplies.sublist(0, 1),
      ),
      Supplier(
        6,
        "Supplier F",
        "0321",
        supplies: supplies.sublist(3, 5),
      ),
      Supplier(
        7,
        "Supplier G",
        "0321",
        supplies: supplies.sublist(1, 4),
      ),
    ];
    List<dynamic> response = [<String>[], []];
    response[1] = suppliers;
    suppliers.forEach((element) {
      response[0].add(element.companyName);
    });
    return Future.value(response);
  }

  static Future<bool> addOrUpdateSupplier(Supplier supplier) async {
    return (Future.value(true));
  }

  static Future<bool> deleteSupplier(Supplier supplier) async {
    return (Future.value(true));
  }
}
