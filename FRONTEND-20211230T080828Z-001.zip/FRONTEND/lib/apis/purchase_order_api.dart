import 'dart:math';

import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/purchase_detail.dart';
import 'package:inventory_management/classes/purchase_order.dart';
import 'package:inventory_management/classes/supplied_by.dart';
import 'package:inventory_management/classes/supplier.dart';

class PurchaseOrderApi {
  static Future<List<PurchaseOrder>> getPurchaseOrders() async {
    List<Product> products = [];
    List<Supplier> suppliers = [
      Supplier(
        1,
        "Supplier A",
        "0321",
      ),
      Supplier(
        2,
        "Supplier B",
        "0321",
      ),
      Supplier(
        3,
        "Supplier C",
        "0321",
      ),
      Supplier(
        4,
        "Supplier D",
        "0321",
      ),
      Supplier(
        5,
        "Supplier E",
        "0321",
      ),
      Supplier(
        6,
        "Supplier F",
        "0321",
      ),
      Supplier(
        7,
        "Supplier G",
        "0321",
      ),
    ];
    List<SuppliedBy> suppliedBy = [
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        10,
        5,
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
    ];
    List<PurchaseOrder> purchaseOrders = [];
    products = [
      Product(
        'Product A',
        'Shampoo',
        20,
        5.1,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
      Product(
        'Product B',
        'Chips',
        17,
        7.0,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
      Product(
        'Product C',
        'Drink',
        25,
        10.2,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
      Product(
        'Product D',
        'Soap',
        50,
        9.4,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
      Product(
        'Product E',
        'Detergent',
        2,
        15,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
      Product(
        'Product F',
        'Oil',
        100,
        2,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
      Product(
        'Product G',
        'Bread',
        100,
        1,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
      Product(
        'Product H',
        'Bun',
        50,
        5,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(3),
          3 + Random().nextInt(suppliedBy.length - 3),
        ),
      ),
    ];

    for (int i = 0; i < 8; i++) {
      purchaseOrders.add(PurchaseOrder(
          i + 1,
          DateTime.now().add(Duration(
            days: Random().nextInt(10),
          )),
          suppliers[Random().nextInt(suppliers.length)],
          20 * Random().nextDouble(),
          DateTime.now(),
          [
            for (int j = 0; j < 1 + Random().nextInt(3); j++)
              PurchaseDetail(products[Random().nextInt(products.length)],
                  Random().nextInt(50), 20 * Random().nextDouble())
          ]));
    }

    //processing api
    //processing api
    for (int i = 0; i < products.length; i++) {
      products[i].id = i + 1;
    }
    return Future.value(purchaseOrders);
  }

  static Future<List<dynamic>> getPOSearch(String search) async {
    List<dynamic> response = [<String>[], []];
    List<Product> products = [];
    List<Supplier> suppliers = [
      Supplier(
        1,
        "Supplier A",
        "0321",
      ),
      Supplier(
        2,
        "Supplier B",
        "0321",
      ),
      Supplier(
        3,
        "Supplier C",
        "0321",
      ),
      Supplier(
        4,
        "Supplier D",
        "0321",
      ),
      Supplier(
        5,
        "Supplier E",
        "0321",
      ),
      Supplier(
        6,
        "Supplier F",
        "0321",
      ),
      Supplier(
        7,
        "Supplier G",
        "0321",
      ),
    ];
    List<SuppliedBy> suppliedBy = [
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        10,
        5,
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
      SuppliedBy(
        suppliers[Random().nextInt(suppliers.length)],
        20 * Random().nextDouble(),
        Random().nextInt(15),
      ),
    ];

    //processing api
    products = [
      Product(
        'Product A',
        'Shampoo',
        20,
        5.1,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
      Product(
        'Product B',
        'Chips',
        17,
        7.0,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
      Product(
        'Product C',
        'Drink',
        25,
        10.2,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
      Product(
        'Product D',
        'Soap',
        50,
        9.4,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
      Product(
        'Product E',
        'Detergent',
        2,
        15,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
      Product(
        'Product F',
        'Oil',
        100,
        2,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
      Product(
        'Product G',
        'Bread',
        100,
        1,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
      Product(
        'Product H',
        'Bun',
        50,
        5,
        suppliedBy: suppliedBy.sublist(
          Random().nextInt(suppliedBy.length - 2),
          Random().nextInt(suppliedBy.length),
        ),
      ),
    ];
    //processing api

    response[1] = products;
    products.forEach((element) {
      response[0].add(element.name);
    });
    return Future.value(response);
  }

  static Future<bool> deletePO(PurchaseOrder purchaseOrder) {
    return Future.value(true);
  }

  static Future<bool> addOrUpdatePO(PurchaseOrder purchaseOrder) {
    return Future.value(true);
  }
}
