import 'package:inventory_management/classes/purchase_detail.dart';
import 'package:inventory_management/classes/supplier.dart';

class PurchaseOrder {
  late int id;
  late DateTime timeOfDelivery;
  late Supplier supplier;
  late double totalAmount;
  late DateTime dateOfPurchase;
  late List<PurchaseDetail> purchaseDetail;
  PurchaseOrder(this.id, this.timeOfDelivery, this.supplier, this.totalAmount,
      this.dateOfPurchase, this.purchaseDetail);
}
