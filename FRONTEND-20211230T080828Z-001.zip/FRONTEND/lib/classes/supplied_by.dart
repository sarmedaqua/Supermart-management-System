import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/supplier.dart';

class SuppliedBy {
  late Supplier supplier;
  late double cost;
  late int days;
  SuppliedBy(this.supplier, this.cost, this.days);
}
