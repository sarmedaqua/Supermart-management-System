import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/supplier.dart';

class Supplies {
  late Product product;
  late double cost;
  late int days;
  Supplies(this.product, this.cost, this.days);
}
