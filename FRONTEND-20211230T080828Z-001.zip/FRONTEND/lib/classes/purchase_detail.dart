import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/supplier.dart';

class PurchaseDetail {
  late Product product;
  late int quantity;
  late double price;
  PurchaseDetail(this.product, this.quantity, this.price);
}
