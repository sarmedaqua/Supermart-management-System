import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/supplies.dart';

class Supplier {
  late int supplierId;
  late String companyName;
  late String phoneNumber;
  List<Supplies>? supplies;
  Supplier(this.supplierId, this.companyName, this.phoneNumber,
      {this.supplies});
}
