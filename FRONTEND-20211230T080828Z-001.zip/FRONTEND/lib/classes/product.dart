import 'package:inventory_management/classes/supplied_by.dart';

class Product {
  int? id;
  late String name;
  late String category;
  late int quantity;
  late double price;
  List<SuppliedBy>? suppliedBy;
  Product(this.name, this.category, this.quantity, this.price,
      {this.suppliedBy, this.id});
}
