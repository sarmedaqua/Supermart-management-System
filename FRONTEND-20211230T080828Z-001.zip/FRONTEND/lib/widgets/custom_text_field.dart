import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomTextField extends StatefulWidget {
  final fontSize;
  Function(String)? onChanged = (_) => null, onSubmitted;
  Function()? onTap = () => null, onEditingComplete;
  String? hintText = '';
  Widget? icon, prefixIcon, suffixIcon;
  TextEditingController? controller;
  bool? enabled, autofocus = false, decoration;
  FocusNode? focusNode;
  BoxDecoration? containerDec;
  Color? color, fillColor, textColor;
  EdgeInsetsGeometry? contentPadding;
  TextInputType? keyboardType;
  TextAlign? allignment;
  int? maxLines;
  Widget? prefixText, suffixText;
  bool? password, isDense, list;
  String? label;
  double? height, width, labelSize;
  EdgeInsetsGeometry? padding;
  CustomTextField(
      {@required this.fontSize,
      this.controller,
      this.hintText,
      this.icon,
      this.onChanged,
      this.enabled = true,
      this.onTap,
      this.prefixIcon,
      this.suffixIcon,
      this.focusNode,
      this.autofocus = false,
      this.color = Colors.grey,
      this.keyboardType = TextInputType.text,
      this.allignment = TextAlign.left,
      this.fillColor = Colors.white,
      this.textColor = Colors.black,
      this.decoration = true,
      this.onEditingComplete,
      this.containerDec,
      this.contentPadding,
      this.onSubmitted,
      this.maxLines = 1,
      this.prefixText,
      this.suffixText,
      this.password = false,
      this.isDense = false,
      this.width,
      this.height,
      this.label,
      this.labelSize,
      this.padding,
      this.list = false}) {
    this.color = this.color == null ? Colors.grey : this.color;
    this.fillColor = this.fillColor == null ? Colors.white : this.fillColor;
    this.textColor = this.textColor == null ? Colors.black : this.textColor;
  }

  @override
  _CustomTextFieldState createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  FocusNode focusNode = FocusNode();
  bool tapped = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    focusNode.addListener(() {
      originNodeListener();
    });
  }

  void originNodeListener() {
    if (focusNode.hasPrimaryFocus && tapped) {
      tapped = false;
      print('focusedddddd');
    } else {
      tapped = false;
      focusNode.unfocus();
      print('unfocused');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.height != null &&
        widget.width != null &&
        widget.padding != null &&
        widget.label != null &&
        widget.labelSize != null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${(widget.controller!.text != '') ? widget.label : ''}',
            style: GoogleFonts.poppins(
              fontWeight: FontWeight.normal,
              fontSize: widget.labelSize,
              color: Colors.black,
            ),
            textAlign: TextAlign.left,
          ),
          Padding(
            padding: (widget.controller!.text != '')
                ? widget.padding!
                : EdgeInsets.zero,
            child: Container(
              clipBehavior: widget.decoration! ? Clip.antiAlias : Clip.none,
              width: widget.width,
              height: widget.height,
              decoration: widget.decoration!
                  ? BoxDecoration(
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromRGBO(0, 0, 0, 0.03),
                          offset: Offset(0, 2),
                          spreadRadius: 0,
                          blurRadius: 10,
                        ),
                      ],
                      color: widget.fillColor,
                      border: Border.all(color: widget.fillColor!),
                      borderRadius: widget.list!
                          ? const BorderRadius.only(
                              topLeft: Radius.circular(6),
                              topRight: Radius.circular(6))
                          : BorderRadius.circular(6),
                    )
                  : widget.containerDec,
              child: TextFormField(
//                textInputAction: TextInputAction.next,
                onFieldSubmitted: (s) {
                  if (widget.onSubmitted != null) widget.onSubmitted!(s);
                },
                onEditingComplete: () {
                  if (widget.onEditingComplete != null)
                    widget.onEditingComplete!();
                  FocusScope.of(context).unfocus();
                },
                keyboardType: widget.keyboardType,
                controller: widget.controller,
                decoration: InputDecoration(
                  prefixIcon: widget.prefixIcon,
                  suffixIcon: widget.suffixIcon,
                  prefix: widget.prefixText,
                  suffix: widget.suffixText,
                  // floatingLabelBehavior: FloatingLabelBehavior.auto,
                  icon: widget.icon,
                  hintText: widget.hintText,
                  border: InputBorder.none,
                  isDense: widget.isDense,
                  disabledBorder: InputBorder.none,
                  // enabledBorder: OutlineInputBorder(
                  //   borderRadius: BorderRadius.zero,
                  //   borderSide: BorderSide(width: 0.1, color: Colors.black),
                  // ),
                  enabledBorder: InputBorder.none,
                  errorBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  focusedErrorBorder: InputBorder.none,
                  fillColor: widget.fillColor,
                  filled: true,
                  contentPadding: widget.contentPadding,
                  hintStyle: GoogleFonts.poppins(
                      fontSize: widget.fontSize,
                      fontWeight: FontWeight.w500,
                      color: widget.color),
                ),
                obscureText: widget.password!,
                textAlign: widget.allignment!,
                autofocus: widget.autofocus!,
                focusNode: widget.focusNode ?? focusNode,
                onTap: () {
                  tapped = true;
                  if (widget.onTap != null) widget.onTap!();
                },
                enabled: widget.enabled,
                style: GoogleFonts.poppins(
                  color: widget.enabled! ? widget.textColor : Colors.grey,
                  fontSize: widget.fontSize,
                  fontWeight: FontWeight.w500,
                ),
                maxLines: widget.maxLines,
                onChanged: widget.onChanged,
              ),
            ),
          )
        ],
      );
    }
    return Container(
      decoration: widget.decoration!
          ? BoxDecoration(
              boxShadow: const [
                BoxShadow(
                  color: Color.fromRGBO(0, 0, 0, 0.03),
                  offset: Offset(0, 2),
                  spreadRadius: 0,
                  blurRadius: 10,
                ),
              ],
              color: widget.fillColor,
              border: Border.all(color: widget.fillColor!),
              borderRadius: widget.list!
                  ? const BorderRadius.only(
                      topLeft: Radius.circular(6), topRight: Radius.circular(6))
                  : BorderRadius.circular(6),
            )
          : widget.containerDec,
      clipBehavior: Clip.antiAlias,
      child: TextField(
        textInputAction: TextInputAction.next,
        onSubmitted:
            // widget.onSubmitted == null
            //     ? (_) => FocusScope.of(context).unfocus():
            widget.onSubmitted,
        onEditingComplete: widget.onEditingComplete,
        keyboardType: widget.keyboardType,
        controller: widget.controller,
        decoration: InputDecoration(
          prefixIcon: widget.prefixIcon,
          suffixIcon: widget.suffixIcon,
          prefix: widget.prefixText,
          suffix: widget.suffixText,
          // floatingLabelBehavior: FloatingLabelBehavior.auto,
          icon: widget.icon,
          hintText: widget.hintText,
          border: InputBorder.none,
          isDense: widget.isDense,
          disabledBorder: InputBorder.none,
          // enabledBorder: OutlineInputBorder(
          //   borderRadius: BorderRadius.zero,
          //   borderSide: BorderSide(width: 0.1, color: Colors.black),
          // ),
          enabledBorder: InputBorder.none,
          errorBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          focusedErrorBorder: InputBorder.none,
          fillColor: widget.fillColor,
          filled: true,
          contentPadding: widget.contentPadding,
          hintStyle: GoogleFonts.poppins(
              fontSize: widget.fontSize,
              fontWeight: FontWeight.w500,
              color: widget.color),
        ),
        obscureText: widget.password!,
        textAlign: widget.allignment!,
        autofocus: widget.autofocus!,
        focusNode: widget.focusNode == null ? focusNode : widget.focusNode,
        onTap: () {
          tapped = true;
          widget.onTap!();
        },
        enabled: widget.enabled,
        style: GoogleFonts.poppins(
          color: widget.enabled! ? widget.textColor : Colors.grey,
          fontSize: widget.fontSize,
          fontWeight: FontWeight.w500,
        ),
        maxLines: widget.maxLines,
        onChanged: widget.onChanged,
      ),
    );
  }
}
