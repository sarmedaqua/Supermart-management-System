import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:inventory_management/widgets/custom_text_field.dart';

class LocationSearchTextField extends StatefulWidget {
  String? searchString = '', country, display;
  Function? callBack, onTap, onChanged;
  Function()? onEditComplete;
  bool? error,
      suffix,
      enabled,
      google,
      dropDownButton,
      showOnEmpty,
      showAll,
      bypass;
  final height, width, screenHeight, screenWidth, authToken, hintText;
  double? tfheight, tfwidth, heightOffset;
  FocusNode? focusNode;
  double? fontSize;
  Function? api;
  TextInputType? keyboardType;
  Map<String, dynamic>? apiArg;
  Color? hintColor, textColor, fillColor;
  String? apiUrl;
  int? maxLines;
  final TextEditingController controller;
  static String apiKey = "AIzaSyDhMAgkU7EKT0PddlSYaBGMHsQDqtuR1bY";
  LocationSearchTextField(this.authToken, this.height, this.width,
      this.screenHeight, this.screenWidth, this.controller, this.hintText,
      {this.searchString,
      this.callBack,
      this.error = false,
      this.keyboardType = TextInputType.text,
      this.google = false,
      this.suffix = true,
      this.focusNode,
      this.onTap,
      this.api,
      this.apiArg,
      this.dropDownButton = false,
      this.showOnEmpty = false,
      this.fontSize,
      this.onChanged,
      this.fillColor,
      this.hintColor,
      this.textColor,
      this.enabled = true,
      this.showAll = false,
      this.bypass = false,
      this.tfwidth,
      this.heightOffset,
      this.onEditComplete,
      this.apiUrl,
      this.country,
      this.maxLines = 1,
      this.display}) {
    if (heightOffset != null) {
      tfheight = height * (heightOffset! / screenHeight);
    }
  }

  @override
  _LocationSearchTextFieldState createState() =>
      _LocationSearchTextFieldState();
}

class _LocationSearchTextFieldState extends State<LocationSearchTextField> {
  List<String> responseString = [];
  List<dynamic> responseId = [];

  Future<void> searchResultsApi() async {
    if (widget.searchString!.length < 3 &&
        widget.focusNode == null &&
        !widget.bypass!) {
      return;
    } else {
      final response = await widget.api!(
        widget.searchString,
      );
      responseString = (response[0] as List<String>);
      responseId = response[1];
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
    widget.searchString = '';
  }

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    widget.searchString = '';
  }

  @override
  Widget build(BuildContext context) {
    if (widget.searchString == '' && !widget.showOnEmpty!)
      setState(() {
        responseString = [];
        responseId = [];
      });

    widget.searchString ??= '';
    // if (widget.showOnEmpty! && widget.searchString!.length == 0) {
    //   searchResultsApi();
    // }
    double containerHeight = widget.heightOffset == null
        ? widget.height *
            (((responseString.length * 36) + 56) / widget.screenHeight)
        : widget.height *
            (((responseString.length * 36) + widget.heightOffset!) /
                widget.screenHeight);
    if (containerHeight > 243.0) containerHeight = 242.0;

    return AnimatedContainer(
      duration: Duration(milliseconds: 400),
      // decoration: BoxDecoration(
      //   boxShadow: [
      //     BoxShadow(
      //       color: Color.fromRGBO(0, 0, 0, 0.03),
      //       offset: Offset(0, 2),
      //       spreadRadius: 0,
      //       blurRadius: 10,
      //     ),
      //   ],
      //   color: widget.fillColor != null ? widget.fillColor : Colors.white,
      //   // border: Border.all(
      //   //     color: widget.fillColor != null ? widget.fillColor : Colors.white),
      //   borderRadius: BorderRadius.circular(6),
      // ),
      child: Column(
        children: <Widget>[
          Container(
            color: Colors.transparent,
            child: Center(
              child: CustomTextField(
                onEditingComplete: widget.onEditComplete,
                keyboardType: widget.keyboardType,
                enabled: widget.enabled,
                fillColor: widget.fillColor,
                textColor: widget.textColor,
                decoration: true,
                list: !(responseString.length == 0 ||
                    (widget.searchString!.length == 0 && !widget.showOnEmpty!)),
                maxLines: widget.maxLines,
                onTap: () {
                  if (widget.showOnEmpty! && responseString.length != 0)
                    setState(() {
                      responseString = [];
                      responseId = [];
                    });
                  else if (widget.showOnEmpty!) {
                    if (!widget.showAll!)
                      widget.searchString = widget.controller.text;
                  } else if (widget.onTap != null) widget.onTap!();
                },
                focusNode: widget.focusNode,
                suffixIcon: widget.suffix == false
                    ? null
                    : widget.dropDownButton!
                        ? GestureDetector(
                            onTap: () {
                              searchResultsApi();
                            },
                            child: Icon(
                              Icons.arrow_drop_down,
                              color: Colors.grey,
                              size: 20,
                            ),
                          )
                        : widget.controller.text == ''
                            ? null
                            : GestureDetector(
                                onTap: () {
                                  widget.controller.clear();
                                  setState(() {
                                    responseString = [];
                                    responseId = [];
                                    widget.callBack!(null);
                                  });
                                },
                                child: Icon(
                                  Icons.clear,
                                  color: Colors.grey,
                                  size: 20,
                                ),
                              ),
                onChanged: (str) {
                  if (widget.onChanged != null) widget.onChanged!();
                  widget.callBack!(null);
                  widget.searchString = str;
                  if (!widget.google!) widget.callBack!(null);
                  if (str.length == 0)
                    setState(() {
                      responseString = [];
                      responseId = [];
                    });
                  else {
                    setState(() {
                      searchResultsApi();
                    });
                  }
                },
                controller: widget.controller,
                fontSize: widget.fontSize == null
                    ? widget.width * (14 / widget.screenWidth)
                    : widget.fontSize,
                hintText: widget.hintText,
                color: widget.error! ? Colors.red : widget.hintColor,
              ),
            ),
            height: widget.tfheight != null
                ? widget.tfheight
                : widget.height * (60 / widget.screenHeight),
            width: widget.tfwidth != null ? widget.tfwidth : null,
          ),
          responseString.length == 0 ||
                  (widget.searchString!.length == 0 && !widget.showOnEmpty!)
              ? Container()
              : Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(
                        color: Color.fromARGB(255, 7, 19, 91).withOpacity(0.6),
                        width: 0.2),
                  ),
                  child: ListView.builder(
                    padding: EdgeInsets.zero,
                    itemBuilder: (ctx, index) {
                      return Padding(
                        padding: EdgeInsets.only(bottom: 10, left: 10),
                        child: GestureDetector(
                          onTap: () => setState(() {
                            FocusScope.of(context).unfocus();
                            widget.searchString = '';
                            if (widget.display != null)
                              widget.controller.text =
                                  responseId[index][widget.display];
                            else
                              widget.controller.text = responseString[index];
                            widget.controller.selection =
                                TextSelection.fromPosition(TextPosition(
                                    offset: widget.controller.text.length));
                            if (widget.callBack != null)
                              widget.callBack!(responseId[index]);
                            if (widget.showOnEmpty!)
                              setState(() {
                                responseString = [];
                              });
                          }),
                          child: Text(
                            responseString[index],
                            style: GoogleFonts.poppins(
                                fontSize:
                                    widget.width * (14 / widget.screenWidth),
                                fontWeight: FontWeight.w500),
                            maxLines: widget.maxLines,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      );
                    },
                    itemCount: responseString.length,
                  ),
                  height: responseString.length == 0 ||
                          (widget.searchString!.length == 0 &&
                              !widget.showOnEmpty!)
                      ? 0
                      : widget.tfheight == null
                          ? containerHeight -
                              widget.height * (63 / widget.screenHeight)
                          : containerHeight -
                              widget.height *
                                  ((widget.heightOffset! + 3) /
                                      widget.screenHeight),
                  width: responseString.length == 0 ||
                          (widget.searchString!.length == 0 &&
                              !widget.showOnEmpty!)
                      ? 0
                      : widget.tfwidth != null
                          ? widget.tfwidth
                          : widget.width * (303 / widget.screenWidth),
                ),
        ],
      ),
      width: widget.tfwidth != null
          ? widget.tfwidth
          : widget.width * (303 / widget.screenWidth),
      height: responseString.length == 0 ||
              (widget.searchString!.length == 0 && !widget.showOnEmpty!)
          ? widget.tfheight != null
              ? widget.height *
                  ((widget.heightOffset! + 3) / widget.screenHeight)
              : widget.height * (63 / widget.screenHeight)
          : containerHeight,
    );
  }
}
