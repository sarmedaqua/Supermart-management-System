import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:inventory_management/apis/product_api.dart';
import 'package:inventory_management/apis/purchase_order_api.dart';
import 'package:inventory_management/apis/supplier_api.dart';
import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/purchase_detail.dart';
import 'package:inventory_management/classes/purchase_order.dart';
import 'package:inventory_management/classes/supplied_by.dart';
import 'package:inventory_management/classes/supplier.dart';
import 'package:inventory_management/items_stuff/product_form.dart';
import 'package:inventory_management/purchase_order_stuff/po_form.dart';
import 'package:inventory_management/supplier_stuff/supplier_form.dart';
import 'package:simple_rich_text/simple_rich_text.dart';

import 'package:inventory_management/classes/supplies.dart';

class PurchaseOrders extends StatefulWidget {
  @override
  State<PurchaseOrders> createState() => _PurchaseOrdersState();
}

class _PurchaseOrdersState extends State<PurchaseOrders> {
  List<PurchaseOrder>? purchaseOrders;
  List<Widget>? suppliersGrid;
  bool addForm = false, edit = false;
  int editIndex = -1;
  Color green = const Color.fromRGBO(0, 115, 86, 1),
      back = const Color.fromRGBO(242, 242, 252, 1);
  double height = 0, width = 0, screenHeight = 780, screenWidth = 360;
  @override
  void didChangeDependencies() {
    if (height == 0) {
      height = MediaQuery.of(context).size.height;
      width = MediaQuery.of(context).size.width;
    }
    super.didChangeDependencies();
  }

  @override
  void initState() {
    PurchaseOrderApi.getPurchaseOrders().then((value) {
      purchaseOrders = value;
      setState(() {});
    });
    super.initState();
  }

  void done() {
    addForm = false;
    edit = false;
    setState(() {});
    PurchaseOrderApi.getPurchaseOrders().then((value) {
      purchaseOrders = value;
      setState(() {});
    });
  }

  h(double x) => height * (x / screenHeight);
  w(double x) => width * (x / screenWidth);
  @override
  Widget build(BuildContext context) {
    return Container(
      width: w(screenWidth * 0.7),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(
                  top: h(5),
                  left: w(10),
                ),
                child: SimpleRichText(
                  'Purchase Orders',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w600,
                    fontSize: 35,
                    color: Colors.black.withOpacity(0.8),
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  top: h(20),
                  left: w(90),
                  right: w(10),
                ),
                child: Material(
                  child: InkWell(
                    splashColor: Colors.white,
                    onTap: () {
                      setState(() {
                        addForm = !addForm;
                      });
                    },
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      width: w(60),
                      height: h(50),
                      decoration: BoxDecoration(
                        color: green.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            addForm
                                ? Container()
                                : const Icon(
                                    Icons.add,
                                    color: Colors.white,
                                  ),
                            Padding(
                              padding: EdgeInsets.only(
                                top: h(0),
                                left: w(3),
                              ),
                              child: SimpleRichText(
                                addForm
                                    ? 'Back to Purchase Orders'
                                    : 'Add Purchase Order',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w500,
                                  fontSize: w(4),
                                  color: Colors.white,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: EdgeInsets.only(top: h(10), left: w(0), bottom: h(10)),
            child: null,
          ),
          Divider(),
          purchaseOrders == null
              ? const CircularProgressIndicator()
              : edit
                  ? POForm(
                      done,
                      purchaseOrder: purchaseOrders![editIndex],
                    )
                  : addForm
                      ? POForm(done)
                      : Container(
                          height: h(screenHeight * 0.7),
                          width: w(screenWidth * 0.7),
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SingleChildScrollView(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h(20),
                                          left: w(0),
                                          bottom: h(20),
                                        ),
                                        child: Row(
                                          children: [
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(10),
                                              ),
                                              child: SimpleRichText(
                                                'PO Id',
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w(4),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(20),
                                              ),
                                              child: SimpleRichText(
                                                'Supplier Name',
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w(4),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(25),
                                              ),
                                              child: SimpleRichText(
                                                'Date of Purchase',
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w(4),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(20),
                                              ),
                                              child: SimpleRichText(
                                                'Total Amount',
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w(4),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(20),
                                              ),
                                              child: SimpleRichText(
                                                'Time of Delivery',
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w(4),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(0),
                                                left: w(20),
                                              ),
                                              child: SimpleRichText(
                                                'Details',
                                                style: GoogleFonts.poppins(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: w(4),
                                                  color: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                textAlign: TextAlign.left,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Divider(),
                                      Padding(
                                        padding: EdgeInsets.only(
                                            top: h(0), left: w(0)),
                                        child: null,
                                      ),
                                      for (int i = 0;
                                          i < purchaseOrders!.length;
                                          i++)
                                        Column(
                                          children: [
                                            Padding(
                                              padding: EdgeInsets.only(
                                                top: h(5),
                                                left: w(10),
                                              ),
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    width: w(screenWidth * 0.1),
                                                    padding: EdgeInsets.only(
                                                      top: h(0),
                                                      left: w(10),
                                                    ),
                                                    child: SimpleRichText(
                                                      purchaseOrders![i]
                                                          .id
                                                          .toString(),
                                                      style:
                                                          GoogleFonts.poppins(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: w(3.5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                      textAlign: TextAlign.left,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        w(screenWidth * 0.135),
                                                    child: SimpleRichText(
                                                      purchaseOrders![i]
                                                          .supplier
                                                          .companyName
                                                          .toString(),
                                                      style:
                                                          GoogleFonts.poppins(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: w(3.5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                      textAlign: TextAlign.left,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        w(screenWidth * 0.16),
                                                    child: SimpleRichText(
                                                      purchaseOrders![i]
                                                          .dateOfPurchase
                                                          .toString(),
                                                      style:
                                                          GoogleFonts.poppins(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: w(3.5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                      textAlign: TextAlign.left,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        w(screenWidth * 0.125),
                                                    child: SimpleRichText(
                                                      purchaseOrders![i]
                                                          .totalAmount
                                                          .toStringAsFixed(2),
                                                      style:
                                                          GoogleFonts.poppins(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: w(3.5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                      textAlign: TextAlign.left,
                                                    ),
                                                  ),
                                                  Container(
                                                    width:
                                                        w(screenWidth * 0.12),
                                                    child: SimpleRichText(
                                                      '\$' +
                                                          purchaseOrders![i]
                                                              .timeOfDelivery
                                                              .toString(),
                                                      style:
                                                          GoogleFonts.poppins(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: w(3.5),
                                                        color: Colors.black
                                                            .withOpacity(0.7),
                                                      ),
                                                      textAlign: TextAlign.left,
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      top: h(0),
                                                      left: w(5),
                                                    ),
                                                    child: Container(
                                                      padding: EdgeInsets.all(
                                                        h(15),
                                                      ),
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        color: Colors.grey
                                                            .withOpacity(0.2),
                                                      ),
                                                      child:
                                                          SingleChildScrollView(
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            for (PurchaseDetail pDetail
                                                                in purchaseOrders![
                                                                        i]
                                                                    .purchaseDetail)
                                                              SimpleRichText(
                                                                '${pDetail.quantity} ${pDetail.product.name.toString()} at \$${pDetail.price.toStringAsFixed(2)} each',
                                                                style:
                                                                    GoogleFonts
                                                                        .poppins(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontSize:
                                                                      w(3.5),
                                                                  color: Colors
                                                                      .black
                                                                      .withOpacity(
                                                                          0.7),
                                                                ),
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                              ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        top: h(0), left: w(10)),
                                                    child: null,
                                                  ),
                                                  InkWell(
                                                    onTap: () {
                                                      setState(() {
                                                        edit = true;
                                                        editIndex = i;
                                                      });
                                                    },
                                                    child: Container(
                                                      child: const Center(
                                                        child: Icon(Icons.edit,
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      padding:
                                                          EdgeInsets.all(h(4)),
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: green
                                                            .withOpacity(0.5),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        top: h(0), left: w(5)),
                                                    child: null,
                                                  ),
                                                  InkWell(
                                                    onTap: () {
                                                      PurchaseOrderApi.deletePO(
                                                              purchaseOrders![
                                                                  i])
                                                          .then((value) {
                                                        purchaseOrders!
                                                            .removeAt(i);
                                                        setState(() {});
                                                      });
                                                    },
                                                    child: Container(
                                                      child: const Center(
                                                        child: Icon(
                                                            Icons.delete,
                                                            color:
                                                                Colors.white),
                                                      ),
                                                      padding:
                                                          EdgeInsets.all(h(4)),
                                                      decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: green
                                                            .withOpacity(0.5),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Divider(),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
        ],
      ),
    );
  }
}
