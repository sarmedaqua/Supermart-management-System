import 'dart:html';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:inventory_management/apis/product_api.dart';
import 'package:inventory_management/apis/purchase_order_api.dart';
import 'package:inventory_management/apis/supplier_api.dart';
import 'package:inventory_management/classes/product.dart';
import 'package:inventory_management/classes/purchase_detail.dart';
import 'package:inventory_management/classes/purchase_order.dart';
import 'package:inventory_management/classes/supplied_by.dart';
import 'package:inventory_management/classes/supplier.dart';
import 'package:inventory_management/classes/supplies.dart';
import 'package:inventory_management/widgets/custom_text_field.dart';
import 'package:inventory_management/widgets/location_search_text_field.dart';
import 'package:simple_rich_text/simple_rich_text.dart';

class POForm extends StatefulWidget {
  PurchaseOrder? purchaseOrder;
  late Function() done;
  POForm(this.done, {this.purchaseOrder});

  @override
  _POFormState createState() => _POFormState();
}

class _POFormState extends State<POForm> {
  double height = 0, width = 0, screenHeight = 780, screenWidth = 360;
  //
  TextEditingController supplierName = TextEditingController();
  //
  List<TextEditingController> products = [];
  List<TextEditingController> quantity = [];
  List<TextEditingController> price = [];
  //
  List<PurchaseDetail> purchaseDetails = [];
  //
  int poDetatails = 1;

  PurchaseOrder? purchaseOrder;
  Supplier? supplier;

  Color green = const Color.fromRGBO(0, 115, 86, 1),
      back = const Color.fromRGBO(242, 242, 252, 1);

  @override
  void initState() {
    purchaseOrder = widget.purchaseOrder;
    if (purchaseOrder != null) {
      supplierName.text = purchaseOrder!.supplier.companyName;
      purchaseDetails = purchaseOrder!.purchaseDetail;
      poDetatails = purchaseOrder!.purchaseDetail.length;
      for (int i = 0; i < purchaseOrder!.purchaseDetail.length; i++) {
        products.add(TextEditingController(
            text: purchaseOrder!.purchaseDetail[i].product.name));
        quantity.add(TextEditingController(
            text: purchaseOrder!.purchaseDetail[i].quantity.toString()));
        price.add(TextEditingController(
          text: purchaseOrder!.purchaseDetail[i].price.toStringAsFixed(3),
        ));
      }
    } else {
      products = [TextEditingController()];
      quantity = [TextEditingController(text: '1')];
      price = [TextEditingController(text: '0')];
    } // TODO: implement initState
    super.initState();
  }

  @override
  void didChangeDependencies() {
    if (height == 0) {
      height = MediaQuery.of(context).size.height;
      width = MediaQuery.of(context).size.width;
    }
    super.didChangeDependencies();
  }

  h(double x) => height * (x / screenHeight);
  w(double x) => width * (x / screenWidth);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: w(screenWidth * 0.65),
      height: h(screenHeight * 0.8),
      child: Stack(
        children: [
          SizedBox(
            width: w(screenWidth * 0.65),
            height: h(screenHeight * 0.7),
            child: Form(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        top: h(10),
                        left: w(0),
                      ),
                      child: SimpleRichText(
                        'Add New Purchase Order',
                        style: GoogleFonts.poppins(
                            fontWeight: FontWeight.w600,
                            fontSize: h(19),
                            color: Colors.black87.withOpacity(0.6),
                            decoration: TextDecoration.underline),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: h(20), left: w(0)),
                      child: null,
                    ),
                    LocationSearchTextField(
                      '',
                      h(screenHeight),
                      w(screenWidth * 0.15),
                      screenHeight,
                      screenWidth,
                      supplierName,
                      'Supplier',
                      fontSize: h(16),
                      textColor: Colors.black.withOpacity(0.5),
                      fillColor: Colors.grey.shade300.withOpacity(0.3),
                      api: SupplierApi.getSuppliersSearch,
                      bypass: true,
                      dropDownButton: true,
                      showAll: true,
                      callBack: (val) {
                        if (val != null) supplier = val;
                      },
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: h(15), left: w(0)),
                      child: null,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (int i = 0; i < poDetatails; i++)
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Center(
                                child: LocationSearchTextField(
                                  '',
                                  h(screenHeight),
                                  w(screenWidth * 0.15),
                                  screenHeight,
                                  screenWidth,
                                  products[i],
                                  'Product',
                                  fontSize: h(16),
                                  textColor: Colors.black.withOpacity(0.5),
                                  fillColor:
                                      Colors.grey.shade300.withOpacity(0.3),
                                  api: ProductApi.getProductsSearch,
                                  bypass: true,
                                  dropDownButton: true,
                                  showAll: true,
                                  callBack: (val) {
                                    if (val == null) return;
                                    if (purchaseDetails.length < poDetatails) {
                                      purchaseDetails.add(PurchaseDetail(
                                        val,
                                        int.parse(quantity[i].text.toString()),
                                        double.parse(price[i].text.toString()),
                                      ));
                                    } else {
                                      purchaseDetails[i].product = val;
                                    }
                                  },
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsets.only(top: h(0), left: w(10)),
                                child: null,
                              ),
                              SizedBox(
                                width: w(screenWidth * 0.1),
                                height: h(screenHeight * 0.1),
                                child: Center(
                                  child: CustomTextField(
                                    width: w(screenWidth * 0.09),
                                    height: h(screenHeight * 0.06),
                                    labelSize: h(10),
                                    controller: price[i],
                                    padding: EdgeInsets.only(top: h(5)),
                                    fontSize: h(16),
                                    textColor: Colors.black.withOpacity(0.5),
                                    fillColor:
                                        Colors.grey.shade300.withOpacity(0.3),
                                    label: 'Price',
                                    hintText: 'Price',
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsets.only(top: h(0), left: w(10)),
                                child: null,
                              ),
                              SizedBox(
                                width: w(screenWidth * 0.1),
                                height: h(screenHeight * 0.1),
                                child: Center(
                                  child: CustomTextField(
                                    width: w(screenWidth * 0.09),
                                    height: h(screenHeight * 0.06),
                                    labelSize: h(10),
                                    controller: quantity[i],
                                    padding: EdgeInsets.only(top: h(5)),
                                    fontSize: h(16),
                                    textColor: Colors.black.withOpacity(0.5),
                                    fillColor:
                                        Colors.grey.shade300.withOpacity(0.3),
                                    label: 'Quantity',
                                    hintText: 'Quantity',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        Padding(
                          padding: EdgeInsets.only(top: h(20), left: w(0)),
                          child: null,
                        ),
                        Row(
                          children: [
                            InkWell(
                              onTap: () {
                                poDetatails++;
                                products.add(TextEditingController());
                                price.add(TextEditingController(text: '0'));
                                quantity.add(TextEditingController(text: '1'));
                                setState(() {});
                              },
                              child: SimpleRichText(
                                'Add another row',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w500,
                                  fontSize: h(15),
                                  color: Colors.grey,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(top: h(0), left: w(10)),
                              child: null,
                            ),
                            InkWell(
                              onTap: () {
                                poDetatails--;
                                products.removeLast();
                                price.removeLast();
                                quantity.removeLast();
                                if (purchaseDetails.length > poDetatails)
                                  purchaseDetails.removeLast();
                                setState(() {});
                              },
                              child: SimpleRichText(
                                'Delete last row',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w500,
                                  fontSize: h(15),
                                  color: Colors.grey,
                                ),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: h(0),
            child: Padding(
              padding: EdgeInsets.only(left: w(70)),
              child: Material(
                child: InkWell(
                  splashColor: Colors.white,
                  onTap: () {
                    for (int i = 0; i < poDetatails; i++) {
                      purchaseDetails[i].quantity =
                          int.parse(quantity[i].text.toString());
                      purchaseDetails[i].price =
                          double.parse(price[i].text.toString());
                    }
                    if (purchaseOrder != null) {
                      purchaseOrder = PurchaseOrder(
                        -1,
                        DateTime.now().add(Duration(days: 20)),
                        supplier!,
                        100,
                        DateTime.now(),
                        purchaseDetails,
                      );
                    } else {
                      purchaseOrder = PurchaseOrder(
                        purchaseOrder!.id,
                        DateTime.now().add(Duration(days: 20)),
                        supplier!,
                        100,
                        DateTime.now(),
                        purchaseDetails,
                      );
                    }

                    PurchaseOrderApi.addOrUpdatePO(purchaseOrder!)
                        .then((value) => widget.done());
                  },
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    width: w(60),
                    height: h(50),
                    decoration: BoxDecoration(
                      color: green.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.check_circle_outline,
                            color: Colors.white,
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                              top: h(0),
                              left: w(3),
                            ),
                            child: SimpleRichText(
                              'Submit',
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w500,
                                fontSize: w(4),
                                color: Colors.white,
                              ),
                              textAlign: TextAlign.left,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
