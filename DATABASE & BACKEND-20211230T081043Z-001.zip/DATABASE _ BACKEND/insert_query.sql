CREATE TABLE job (
job_id NUMBER(6) PRIMARY KEY
);
CREATE TABLE role (
role_id NUMBER(6) PRIMARY KEY
);
CREATE TABLE employees (
employee_id  NUMBER(6) PRIMARY KEY,
first_name VARCHAR2(100),
last_name VARCHAR2(100),
email VARCHAR2(100),
phone_number VARCHAR2(13),
hired_date date,
manager_id  NUMBER(6),
address VARCHAR2(100),
salary number(8,2),
role_id NUMBER(6),
job_id NUMBER(6),
CONSTRAINT FK_jid FOREIGN KEY (job_id) REFERENCES job(job_id),
CONSTRAINT FK_rid FOREIGN KEY (role_id) REFERENCES role(role_id)
);
CREATE TABLE employee_attendance (
day date PRIMARY KEY,
employee_id number(6),
entry_time time,
exit_time time,
on_leave char(1),
CONSTRAINT FK_eid FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);

CREATE TABLE employee_attendance (
day date PRIMARY KEY,
employee_id number(6),
entry_time TIMESTAMP ,
exit_time TIMESTAMP,
on_leave char(1),
CONSTRAINT FK_eid FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);
CREATE TABLE category (
category_id number(6) primary key,
name VARCHAR2(20),
description VARCHAR(100)
);
CREATE TABLE products (
product_id number(6) PRIMARY KEY,
name VARCHAR2(20),
product_type VARCHAR2(50),
qty_stock number(5),
price number(5),
category_id number(6),
CONSTRAINT FK_cpid FOREIGN KEY (category_id) REFERENCES category(category_id)
);
CREATE TABLE orders_detail (
order_id varchar2(20),
product_id number(6),
sales_time timestamp,
quantity number(6),
CONSTRAINT FK_ooid FOREIGN KEY (order_id) REFERENCES orders(order_id),
CONSTRAINT FK_pid FOREIGN KEY (product_id) REFERENCES products(product_id)
);
CREATE TABLE supplier (
supplier_id number(6) primary key,
company_name VARCHAR2(20),
phone_number VARCHAR2(15)
);
CREATE TABLE purchase_order (
purchase_id number(6) PRIMARY KEY,
purchase_time timestamp,
dop date,
total_amount number(6),
supplier_id number(6),
CONSTRAINT FK_sid FOREIGN KEY (supplier_id) REFERENCES supplier(supplier_id)
);
CREATE TABLE purchase_detail (
purchase_id number(6),
product_id number(6),
purchase_price number(6),
quantity number(6),
CONSTRAINT FK_pupdid FOREIGN KEY (purchase_id) REFERENCES purchase_order(purchase_id),
CONSTRAINT FK_ppdid FOREIGN KEY (product_id) REFERENCES products(product_id)
);
INSERT INTO role VALUES (300000,'Customer relation');
INSERT INTO job VALUES (400000,'Cashier');
INSERT INTO employees VALUES (100000,'Ali', 'ahmed', 'ali@gmail.com','345343563',TO_DATE('14.09.2007','DD.MM.YYYY'),200000,'clifton',20000,300000,400000);
INSERT INTO employee_attendance VALUES (TO_DATE('24.09.2014','DD.MM.YYYY'),100000,TO_TIMESTAMP('24.09.2014 08:45:00', 'DD.MM.YYYY HH24:MI:SS'),TO_TIMESTAMP('24.09.2014 17:45:00', 'DD.MM.YYYY HH24:MI:SS'),'n');
INSERT INTO users VALUES ('ali',100000,'ali@cashier');
INSERT INTO customers VALUES (500000,'Qasim','john','452333636');
commit;
