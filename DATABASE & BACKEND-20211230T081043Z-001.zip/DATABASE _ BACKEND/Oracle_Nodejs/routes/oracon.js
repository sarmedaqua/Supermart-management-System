var express = require('express');
var router = express.Router();
var oracledb=require('oracledb');
/*
var constring='(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = orclpdb)))';
oracledb.getConnection({
    username:'db',
    password:'proj',
    tns:constring
},function(err){
    if(err){
        throw err;
    }
    console.log('Successfully connected');
});

db.connect((err)=>{
    if(err){
        throw err;
    }
    console.log('Successfully connected');
});
*/
router.post('/first',function(req,res,next){
    const {employee_id,first_name,last_name,email,phone_number,hired_date,manager_id,address,salary,role_id,job_id}=req.body;

    var constring='(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = orclpdb)))';
    oracledb.getConnection({
        user:"db",
        password:"proj",
        tns:constring
    },function(err,con){
        if(err){
            res.send('db con error');
            console.log('not connected');
        }else{
            var q="insert into employees values('"+employee_id+"','"+first_name+"','"+last_name+"','"+email+"','"+phone_number+"','"+hired_date+"','"+manager_id+"','"+address+"','"+salary+"','"+role_id+"','"+job_id+"')";
        con.execute(q,[],{autoCommit:true},function(e,s){
            if(e){
                res.send(e);
            }else{
                res.send(s);
            }
        })
        }
        })
});
router.post('/job',function(req,res,next){
    const {job_id,job_title}=req.body;

    var constring='(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = orclpdb)))';
    oracledb.getConnection({
        user:"db",
        password:"proj",
        tns:constring
    },function(err,con){
        if(err){
            res.send('db con error');
            console.log('not connected');
        }else{
            var q="insert into job values('"+job_id+"','"+job_title+"')";
        con.execute(q,[],{autoCommit:true},function(e,s){
            if(e){
                res.send(e);
            }else{
                res.send(s);
            }
        })
        }
        })
});

router.post('/role',function(req,res,next){
    const {role_id,role_title}=req.body;

    var constring='(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = orclpdb)))';
    oracledb.getConnection({
        user:"db",
        password:"proj",
        tns:constring
    },function(err,con){
        if(err){
            res.send('db con error');
            console.log('not connected');
        }else{
            var q="insert into job values('"+role_id+"','"+role_title+"')";
        con.execute(q,[],{autoCommit:true},function(e,s){
            if(e){
                res.send(e);
            }else{
                res.send(s);
            }
        })
        }
        })
});


module.exports=router;